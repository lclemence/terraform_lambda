require 'json'
require 'aws-sdk'

BOXESDB = Aws::DynamoDB::Resource.new(region: 'us-west-2').table('boxes')

class ApiController
  def self.render(code:, body:)
    { statusCode: code,
      body: body.to_json,
      headers: {
            'Content-Type': 'application/json',
        }
      }
  end
end

class BoxesController < ApiController
  def self.index(event:, context:)
    result = BOXESDB.scan
    render(code: 200, body: result.items)
  end

  def self.create(event:, context:)
    item = { id: SecureRandom.uuid,
             serial_number: event['serial_number']
    }
    BOXESDB.put_item(item: item)
    render(code: 200, body: item)
  end

  def self.update(event:, context:)
    item = { id: event['id'],
             serial_number: event['serial_number']
    }
    BOXESDB.put_item(item: item)
    render(code: 200, body: item)
  end

  def self.get(event:, context:)
    result = BOXESDB.query({
      key_condition_expression: 'id = :id',
      expression_attribute_values: {
        ':id' => event['id']
      }
    })
    render(code: 200, body: result.items.first)
  end
end
